# Assignment 1

## Students
- Tiger Ding
- Zihao Zhao

## Contributions
- Zihao Zhao
```
uint256_create_from_u32
uint256_create
uint256_mul
uint256_lshift
associated tests
```

- Tiger Ding
```
uint256_get_bits
uint256_is_bit_set
uint256_create_from_hex
uint256_format_as_hex
uint256_add
uint256_sub
uint256_negate
associated tests
```
